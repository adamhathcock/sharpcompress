#!/bin/bash

${SRCROOT}/Scripts/package_moltenvk.sh
${SRCROOT}/Scripts/package_shader_converter.sh
${SRCROOT}/Scripts/package_docs.sh
${SRCROOT}/Scripts/update_latest.sh

