@interface EmptyClass
@end