@implementation EmptyClass
@end