#import <PosModule/PosModule.h>

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, NSStringFromClass([App class]), NSStringFromClass([AppDelegate class]));
    }
}

